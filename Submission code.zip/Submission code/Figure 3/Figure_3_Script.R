#Publication ready figure 3

#housekeeping######
if (!require(readxl)) install.packages('readxl')
library(readxl)

if (!require(tidyr)) install.packages('tidyr')
library(tidyr)

if (!require(dplyr)) install.packages('dplyr')
library(dplyr)

if (!require(wesanderson)) install.packages('wesanderson')
library(wesanderson)

if (!require(chron)) install.packages('chron')
library(chron)

if (!require(cowplot)) install.packages('cowplot')
library(cowplot)

if (!require(stats)) install.packages('stats')
library(stats)

if (!require(ggplot2)) install.packages('ggplot2')
library(ggplot2)

if (!require(lubridate)) install.packages('lubridate')
library(lubridate)

if (!require(viridis)) install.packages('viridis')
library(viridis)


full_pallett<-viridis_pal(option = "B")(10)
sub_pallett<-c((full_pallett[7]), (full_pallett[3]))
sub_pallett2<-c((full_pallett[5]), (full_pallett[9]))



#Results Figure 3 #######
#import Data

Labelled_flux_data<-read.delim2("Labeled_chamber_LGR_Processed_files_24-25.08.2022.csv", header = TRUE, sep = ",", dec = ".") #loading data set 

Labelled_flux_data$datetime<-as.POSIXct(Labelled_flux_data$datetime)

#tidying up the figure lid labels
Labelled_flux_data[82798:82950, 30]<- "Open"

Labelled_flux_data[84500:84521, 30]<- "Open"

Labelled_flux_data[86781:86850, 30]<- "Open"



#part a ##### 

Labelled_flux_data1<-(Labelled_flux_data[82680:88821,])
Labelled_flux_data1$Time2<-as.POSIXct(Labelled_flux_data1$Time2, format = "%H:%M:%S", tz = "UTC")


first_look_CH4<- ggplot(data=Labelled_flux_data1, aes(x=Time2, y=CH4))+
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "10 mins")+
  geom_point(aes(color = Chamber_Lid))+
  xlab("Time (24 Hour Clock)") +
  ylab(expression("CH"[4]*" Concentration (ppm)"))+
  scale_color_manual(name = "    Chamber Cycle", labels = c("Measurement", "Ventilation"), values = sub_pallett)+
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12, face = "bold"),
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.y = element_text(size = 8),
    legend.position = "right"
  )


figure_a<- first_look_CH4 + theme(legend.position = "none")
figure_a_legend <- get_legend(first_look_CH4) #use plot(legend) to view




#part b ####

Run_43_data<-read.delim2("chamber_run_43.csv", header = TRUE, sep = ",", dec = ".") #loading data set 
Run_43_data$datetime<-as.POSIXct(Run_43_data$datetime)

Run_43_data_graph<- ggplot(data=Run_43_data, aes(x=datetime, y=CH4))+
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "10 mins")+
  geom_point(aes(color = Chamber_Lid))+
  xlab("Time (24 Hour Clock)") +
  ylab(expression("CH"[4]*" Concentration (ppm)"))+
  scale_color_manual(values = sub_pallett)+
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_blank(),
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.y = element_text(size = 8),
    legend.position = "none"
  )

Run_43_data_graph

#model ch4
hour.1<-Run_43_data
a_reg<-lm(CH4 ~ datetime, data = hour.1)
a_coeff=coefficients(a_reg)
a_coeff_df<-(data.frame(a_coeff))
a_intercept<-(a_coeff_df[1,])
a_slope<-(a_coeff_df[2,])
a_Diffusion_fit<-summary(a_reg)$r.squared

  
  a_eq = paste0("y = ", round(a_coeff[2],5), "*x + ", round(a_coeff[1],2))
  a<-Run_43_data_graph + geom_abline(intercept =  a_intercept, slope = a_slope  ,color="black", linetype = "longdash")+
    xlab("Time (24 Hour Clock)") +
    ylab(expression ("CH"[4]*" Concentration (ppm)"))+
    scale_linetype_manual(values = "dashed", name = "Line Types")+
    theme(text = element_text(size=10),
          plot.title = element_text(size=10))
  
figure_b<- a
figure_b
  
  
#part c ######
  
  Run_5_data<-read.delim2("chamber_run_5_adjusted.csv", header = TRUE, sep = ",", dec = ".") #loading data set 
  Run_5_data$datetime<-as.POSIXct(Run_5_data$datetime)
  
  Run_5_data_graph<- ggplot(data=Run_5_data, aes(x=datetime, y=CH4))+
    scale_x_datetime(date_labels = "%H:%M", date_breaks = "10 mins")+
    geom_point(aes(color = Chamber_Lid))+
    xlab("Time (24 Hour Clock)") +
    ylab(expression("CH"[4]*" Concentration (ppm)"))+
    scale_color_manual(values = sub_pallett)+
    theme(
      panel.background = element_rect(fill = "white", colour = "white"),
      panel.grid = element_blank(),
      axis.line = element_line(color = "black"),
      legend.background = element_rect(fill = "white"),
      legend.title = element_blank(),
      legend.key.size = unit(2, "lines"),
      legend.text = element_text(size = 12),
      plot.title = element_text(size = 10, face = "bold"),
      axis.text.y = element_text(size = 8),
      plot.margin = margin(10, 15, 10, 10),
      legend.position = "none"
    )
  
  Run_5_data_graph

  

  
  bubble_data<-rbind((Run_5_data[1, ]), (Run_5_data[(NROW(na.omit(Run_5_data))), ]))
  
  a_reg<-lm(CH4 ~ datetime, data = bubble_data)
  a_coeff=coefficients(a_reg)
  a_coeff_df<-(data.frame(a_coeff))
  a_intercept<-(a_coeff_df[1,])
  a_slope<-(a_coeff_df[2,])
  
  a_eq = paste0("y = ", round(a_coeff[2],5), "*x + ", round(a_coeff[1],2))
  a<-Run_5_data_graph + geom_abline(intercept =  a_intercept, slope = a_slope  ,color="black", linetype = "longdash")+
    xlab("Time (24 Hour Clock)") +
    ylab(expression ("CH"[4]*" Concentration (ppm)"))+
    theme(text = element_text(size=10),
          axis.text.x = element_text(size=10),
          axis.text.y = element_text(size=10),
          plot.title = element_text(size=10))
  figure_c<- a

   
   
#part d #####
   
   compiled_rates_data<-read_xlsx("compiled_Spring_P1_Josephine.xlsx") #loading data set 
   compiled_rates_data$datetime<-as.POSIXct(compiled_rates_data$datetime)
   compiled_rates_data$CH4_mg_day_m<-((compiled_rates_data$CH4_rate_m)* ((0.02675*(compiled_rates_data$pressure_Pa))/(0.09621127502*(8.3143*(compiled_rates_data$Temp_C))))*10^-6 *86400*10^3 *16) #8640 as written in the paper or 86400 as in seconds in the day?
   
   
   
   Rate_extractions_graph_ch4<- ggplot(data=compiled_rates_data, aes(x=datetime, y=CH4_mg_day_m ))+
     scale_x_datetime(date_labels = "%H:%M", date_breaks = "2 hour")+
     geom_point(aes(color = CH4_ebbulition), size = 2)+
     xlab("Time (24 Hour Clock)") +
     ylab(expression ("CH"[4]*" Flux (mg m"^{-2}* " day"^{-1}*")"))+
     scale_color_manual(name = "Emission Pathway", labels = c("Diffusion", "Ebbullition"), values = sub_pallett2)+
     theme(
       panel.background = element_rect(fill = "white", colour = "white"),
       panel.grid = element_blank(),
       axis.line = element_line(color = "black"),
       legend.background = element_rect(fill = "white"),
       legend.title = element_text(size = 12, face = "bold") ,
       legend.key.size = unit(2, "lines"),
       legend.text = element_text(size = 12),
       plot.title = element_text(size = 10, face = "bold"),
       axis.text.y = element_text(size = 8),
       legend.position = "right"
     )
   
  figure_d<- Rate_extractions_graph_ch4 + theme(legend.position = "none")
  figure_d_legend <- get_legend(Rate_extractions_graph_ch4) #use plot(figure_d_legend) to view
   
   

   
   
#figure 3 final plot##########
   
   # adjusting the plot

   #part a 
   
   Labelled_flux_data1<-(Labelled_flux_data[82680:88821,])
   Labelled_flux_data1$Time2<-as.POSIXct(Labelled_flux_data1$Time2, format = "%H:%M:%S", tz = "UTC")
   
   
   first_look_CH4<- ggplot(data=Labelled_flux_data1, aes(x=Time2, y=CH4))+
     scale_x_datetime(date_labels = "%H:%M", date_breaks = "20 mins")+
     geom_point(aes(color = Chamber_Lid), size = 1.5, fill = "white", shape = 21, stroke = 1) +  # White fill, colored border
     xlab("Time (24 hour clock)") +
     ylab(expression(bold("CH"[4]*" Concentration (ppm)")))+
     scale_y_continuous(
       breaks = seq(min(1.9), 2.3, length.out = 5),  # Set the upper limit to 80
       limits = c(min(1.9), 2.3),                    # Force the y-axis to extend up to 80
       labels = scales::label_number(accuracy = 0.1)
     ) +
     scale_color_manual(name = "    Chamber Cycle", labels = c("Measurement", "Ventilation"), values = sub_pallett)+
     theme(
       panel.background = element_rect(fill = "white", colour = "white"),
       panel.grid = element_blank(),
       axis.line = element_line(color = "black"),
       legend.background = element_rect(fill = "white"),
       legend.title = element_text(size = 12) ,
       legend.key.size = unit(2, "lines"),
       legend.text = element_text(size = 12),
       plot.title = element_text(size = 10, face = "bold"),
       axis.text.x = element_text(size = 10),
       axis.text.y = element_text(size = 10),
       axis.title.x = element_text(size = 10, face = "bold"),  # Bold x-axis label
       axis.title.y = element_text(size = 10, margin = margin(t = 0, r = 8, b = 0, l = 0)),
       legend.position = "right")
   
   figure_a<- first_look_CH4 + theme(legend.position = "none")
   figure_a_legend <- get_legend(first_look_CH4) #use plot(legend) to view
   
   
   
   
   #part b 
   
   Run_43_data<-read.delim2("chamber_run_43.csv", header = TRUE, sep = ",", dec = ".") #loading data set 
   Run_43_data$datetime<-as.POSIXct(Run_43_data$datetime)
   
   Run_43_data_graph<- ggplot(data=Run_43_data, aes(x=datetime, y=CH4))+
     geom_point(aes(color = Chamber_Lid), size = 1.5, fill = "white", shape = 21, stroke = 1) +  # White fill, colored border
     scale_x_datetime(date_labels = "%H:%M", date_breaks = "6 mins",  limits = c(as.POSIXct("2022-05-30 16:26"), as.POSIXct("2022-05-30 16:54")))+
        scale_y_continuous(
       breaks = seq(min(1.9), 2.25, length.out = 5),  # Set the upper limit to 80
       limits = c(min(1.9), 2.25),                    # Force the y-axis to extend up to 80
       labels = scales::label_number(accuracy = 0.01)
     ) +
     xlab("Time (24 hour clock)") +
     ylab(expression(bold("CH"[4]*" Concentration (ppm)")))+
     scale_color_manual(values = sub_pallett)+
     theme(
       panel.background = element_rect(fill = "white", colour = "white"),
       panel.grid = element_blank(),
       axis.line = element_line(color = "black"),
       legend.background = element_rect(fill = "white"),
       legend.title = element_text(size = 12) ,
       legend.key.size = unit(2, "lines"),
       legend.text = element_text(size = 12),
       plot.title = element_text(size = 10, face = "bold"),
       axis.text.x = element_text(size = 10),
       axis.text.y = element_text(size = 10),
       axis.title.x = element_text(size = 10, face = "bold"),  # Bold x-axis label
       axis.title.y = element_text(size = 10),
       legend.position = "none")
   
   Run_43_data_graph
   
   #model ch4
   hour.1<-Run_43_data
   a_reg<-lm(CH4 ~ datetime, data = hour.1)
   a_coeff=coefficients(a_reg)
   a_coeff_df<-(data.frame(a_coeff))
   a_intercept<-(a_coeff_df[1,])
   a_slope<-(a_coeff_df[2,])
   a_Diffusion_fit<-summary(a_reg)$r.squared
   
   
   a_eq = paste0("y = ", round(a_coeff[2],5), "*x + ", round(a_coeff[1],2))
   a<-Run_43_data_graph + geom_abline(intercept =  a_intercept, slope = a_slope  ,color="black", linetype = "longdash")+
     scale_linetype_manual(values = "dashed", name = "Line Types")
   
   figure_b<- a
   figure_b
   
   
   #part c 
   
   
   
   Run_5_data<-read.delim2("chamber_run_5_adjusted.csv", header = TRUE, sep = ",", dec = ".") #loading data set 
   Run_5_data$datetime<-as.POSIXct(Run_5_data$datetime)
   
   Run_5_data_graph<- ggplot(data=Run_5_data, aes(x=datetime, y=CH4))+
     scale_x_datetime(date_labels = "%H:%M", date_breaks = "7.5 mins")+
     
     geom_point(aes(color = Chamber_Lid), size = 1.5, fill = "white", shape = 21, stroke = 1) +  # White fill, colored border
     xlab("Time (24 hour clock)") +
     ylab(expression(bold("CH"[4]*" Concentration (ppm)")))+
     scale_color_manual(values = sub_pallett)+
     theme(
       panel.background = element_rect(fill = "white", colour = "white"),
       panel.grid = element_blank(),
       axis.line = element_line(color = "black"),
       legend.background = element_rect(fill = "white"),
       legend.title = element_text(size = 12) ,
       legend.key.size = unit(2, "lines"),
       legend.text = element_text(size = 12),
       plot.title = element_text(size = 10, face = "bold"),
       axis.text.x = element_text(size = 10),
       axis.text.y = element_text(size = 10),
       axis.title.x = element_text(size = 10, face = "bold"),  # Bold x-axis label
       axis.title.y = element_text(size = 10),
       plot.margin = unit(c(5.5, 10, 5.5, 5.5), "pt"),
       legend.position = "none")
   
   Run_5_data_graph
   
   
   
   
   bubble_data<-rbind((Run_5_data[1, ]), (Run_5_data[(NROW(na.omit(Run_5_data))), ]))
   
   a_reg<-lm(CH4 ~ datetime, data = bubble_data)
   a_coeff=coefficients(a_reg)
   a_coeff_df<-(data.frame(a_coeff))
   a_intercept<-(a_coeff_df[1,])
   a_slope<-(a_coeff_df[2,])
   
   a_eq = paste0("y = ", round(a_coeff[2],5), "*x + ", round(a_coeff[1],2))
   a<-Run_5_data_graph + geom_abline(intercept =  a_intercept, slope = a_slope  ,color="black", linetype = "longdash")
   
   figure_c<- a
   
   
   
   #part d 
   
   compiled_rates_data<-read_xlsx("compiled_Spring_P1_Josephine.xlsx") #loading data set 
   compiled_rates_data$datetime<-as.POSIXct(compiled_rates_data$datetime)
   compiled_rates_data$CH4_mg_day_m<-((compiled_rates_data$CH4_rate_m)* ((0.02675*(compiled_rates_data$pressure_Pa))/(0.09621127502*(8.3143*(compiled_rates_data$Temp_C))))*10^-6 *86400*10^3 *16) #8640 as written in the paper or 86400 as in seconds in the day?
   
   
   
   Rate_extractions_graph_ch4<- ggplot(data=compiled_rates_data, aes(x=datetime, y=CH4_mg_day_m ))+
     scale_y_continuous(trans='log2')+
     scale_x_datetime(date_labels = "%H:%M", date_breaks = "5 hour", limits = c(as.POSIXct("2022-05-29 16:00"), as.POSIXct("2022-05-30 18:00")))+
     geom_point(aes(color = CH4_ebbulition), size = 2)+
     xlab("Time (24 hour clock)") +
     ylab(expression(bold("CH"[4]*" Flux (mg m"^{-2}* " day"^{-1}*")")))+
     scale_color_manual(name = "Emission Pathway", labels = c("Diffusive", "Ebullitive"), values = sub_pallett2)+
     theme(
       panel.background = element_rect(fill = "white", colour = "white"),
       panel.grid = element_blank(),
       axis.line = element_line(color = "black"),
       legend.background = element_rect(fill = "white"),
       legend.title = element_text(size = 12) ,
       legend.key.size = unit(2, "lines"),
       legend.key = element_rect(fill = "white", colour = NA),
       legend.text = element_text(size = 12),
       plot.title = element_text(size = 10, face = "bold"),
       axis.text.x = element_text(size = 10),
       axis.text.y = element_text(size = 10),
       axis.title.x = element_text(size = 10, face = "bold"),  # Bold x-axis label
       axis.title.y = element_text(size = 10, margin = margin(t = 0, r = 8, b = 0, l = 0)),
       legend.position = "right",
       legend.key.height = unit(0.4, "cm"), 
       legend.spacing.x = unit(-0.2, "cm"))
   
   
   figure_d<- Rate_extractions_graph_ch4 + theme(legend.position = "none")
   figure_d_legend <- get_legend(Rate_extractions_graph_ch4) #use plot(figure_d_legend) to view
   plot(figure_d_legend)
   
   
   #Figure 3 final plot

   
   middle_row <- plot_grid(figure_b, figure_c, ncol = 2)  # Top row: p1 and p2 side by side
   final_plot <- plot_grid(figure_a, middle_row, figure_d, ncol = 1, rel_heights = c(1, 1))  # Combine rows
   
   # Display the plot
   final_plot
   
   
   
   
   
   #save plot
   
   ggsave("Figure_3.png", width = 140, height = 175, units = "mm") #saving the graph to the file directory
   
   
   final_plot
   
   
   #dev.off()
   (while (!is.null(dev.list()))  dev.off())   
   
   
   #save figure a, b and c legend
   
   ggsave("Figure_3abc_legend.png", plot = figure_a_legend, width = 50, height = 50, units = "mm")
   
   #dev.off()
   (while (!is.null(dev.list()))  dev.off())   
   
   
   #save figure d legend
   ggsave("Figure_3d_legend.png", plot = figure_d_legend, width = 50, height = 50, units = "mm")
   
   #dev.off()
   (while (!is.null(dev.list()))  dev.off()) 
   
   
   
   