This folder creates Figure 4:

Flux extraction process for multiple-chamber runs using five chambers connected by a valve changer. a) Subsample of raw CO2 data from a 24-h deployment displaying three measurement cycles or headspace isolation periods. Each of the colours denotes a different chamber, while the grey bars represent headspace ventilation periods. b) Isolated CO2 data from a single measurement cycle, the slopes of the lines of best fit representing the fluxes for each of the five chambers. c) Example of a large CH4 ebullition event occurring in one of the five chambers (black symbols) part way through the measurement cycle, while the other chambers (coloured symbols) remain unaffected, exhibiting predominantly diffusive flux. The y-axis is presented on a log₁₀ scale. d) Compiled flux measurements for a full 24-hour deployment period for five chambers, y-axis presented on a log₁₀ scale.

R version 4.3.0 is used.

The script isolates the measurement data from non-measurement data and plots it ready for publication. 
