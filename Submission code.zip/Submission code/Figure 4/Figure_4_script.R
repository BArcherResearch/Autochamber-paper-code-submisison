#Figure 4 publication ready figure

#House keeping #####
if (!require(readxl)) install.packages('readxl')
library(readxl)

if (!require(tidyr)) install.packages('tidyr')
library(tidyr)

if (!require(dplyr)) install.packages('dplyr')
library(dplyr)

if (!require(wesanderson)) install.packages('wesanderson')
library(wesanderson)

if (!require(chron)) install.packages('chron')
library(chron)

if (!require(cowplot)) install.packages('cowplot')
library(cowplot)

if (!require(stats)) install.packages('stats')
library(stats)

if (!require(ggplot2)) install.packages('ggplot2')
library(ggplot2)

if (!require(lubridate)) install.packages('lubridate')
library(lubridate)

if (!require(viridis)) install.packages('viridis')
library(viridis)

if (!require(parallel)) install.packages('parallel')
library(parallel)

if (!require(rlang)) install.packages('rlang')
library(rlang)

#fantastic<-wes_palette(name = "Zissou1") #non colourblind pallet
fantastic<- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7") #colourblind pallet



full_pallett<-viridis_pal(option = "B")(10)
sub_pallett<-c((full_pallett[1]), (full_pallett[4]), (full_pallett[6]), (full_pallett[8]), (full_pallett[9]))
sub_pallett2<-c((full_pallett[1]), (full_pallett[9]))


#Importing LGR data###
#This includes setting up the times into usable formats etc

day_1<-read.delim2("LGR_Data/2022-05-14/gga_2022-05-14_f0000/gga_2022-05-14_f0000_no_title.txt", header = TRUE, sep = ",", dec = ".")
day_2<-read.delim2("LGR_Data/2022-05-15/gga_2022-05-15_f0000_no_title.txt", header = TRUE, sep = ",", dec = ".")
hour.1<- rbind(day_1, day_2)


#changing colum titles
names(hour.1)[names(hour.1) == "X.CH4.d_ppm"] <- "CH4"
names(hour.1)[names(hour.1) == "X.CO2.d_ppm"] <- "CO2"
names(hour.1)[names(hour.1) == "X.H2O._ppm"] <- "H2O"


#creating new time column

hour.1<-separate(data = hour.1, col = Time, into = c("Month", "Day", "Year"), sep = "/")

hour.1<-separate(data = hour.1, col = Year, into = c("Year", "Time1"), sep = " ")

hour.1$Time2<-as.times(hour.1$Time1)

hour.1$Time3<-(hour.1$Time2)

hour.1<-separate(data = hour.1, col = Time3, into = c("Hours", "Minutes", "Seconds"), sep = ":")

hour.1$datetime<-ymd_hms(paste(hour.1$Year, hour.1$Month, hour.1$Day, hour.1$Time2, sep="-"))

hour.1$Time3<-as.numeric(hour.1$datetime)

seconds_offset_to_zero<-(hour.1[1,33])
seconds_offset_to_zero #check it is the first value for Time1
rows_numbers<-(NROW(na.omit(hour.1)))
rows_numbers

hour.1 <- na.omit(hour.1)



for(i in 1:(rows_numbers)) {                                    #setting the seconds to 0 based upon the date
  
  hour.1[(i),34]<-((hour.1[(i),33])-seconds_offset_to_zero)
  
}


names(hour.1)[34] <- "Total_Mins"                                     #converting column 26 to minutes of experiment from 0

hour.1$Total_Mins<-((hour.1$Total_Mins)/60)


#reducing the size of the data set for the figure ####
figure_data1<-(hour.1[450:nrow(hour.1), ])


#quick view of plot

ggplot(data=na.omit(figure_data1), aes(x=datetime, y=CO2))+
  geom_point()+
  xlab("Time (24 hour clock)") +
  ylab(expression(bold("CO"[2]*" Concentration (ppm)")))+
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12) ,
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10, face = "bold"),  # Bold x-axis label
    axis.title.y = element_text(size = 10),
    legend.position = "right")


figure_data1$Time3<-((figure_data1$Time3)+1052) 


#reading data from the valve changer ####

Valve_data<-read.delim2("STATUS_for_r.txt", header = TRUE, sep = ",", dec = ".")


Valve_data$Time<-as.times(Valve_data$Time)

Valve_data<-separate(data = Valve_data, col = Date, into = c("Day", "Month", "Year"), sep = "_")

Valve_data$Date<-ymd(paste(Valve_data$Year, Valve_data$Month, Valve_data$Day, sep="-"))

Valve_data$datetime<-ymd_hms(paste(Valve_data$Date, Valve_data$Time, sep="-"))

Valve_data<-separate(data = Valve_data, col = Code, into = c("text", "code"), sep = ": ")

Valve_data <- Valve_data[ -c(1, 2, 3, 5, 7) ]

Valve_data <- Valve_data [, c(4, 3, 1, 2)]

Valve_data$Time1<-as.numeric(Valve_data$datetime)

rows_numbers<-(NROW(na.omit(Valve_data)))



#convering the codes into written text for ease of understanding ######
#previous code improved my using parallel processing

# Define your code_map
code_map <- c(
  "111" = "Power_On",
  "100" = "Chamber_1_not_closed_raio_timeout_no_communication",
  "101" = "Chamber_2_not_closed_raio_timeout_no_communication",
  "102" = "Chamber_3_not_closed_raio_timeout_no_communication",
  "103" = "Chamber_4_not_closed_raio_timeout_no_communication",
  "104" = "Chamber_5_not_closed_raio_timeout_no_communication",
  "0"   = "Chamber_1_sucessfully_closed",
  "1"   = "Chamber_2_sucessfully_closed",
  "2"   = "Chamber_3_sucessfully_closed",
  "3"   = "Chamber_4_sucessfully_closed",
  "4"   = "Chamber_5_sucessfully_closed",
  "30"  = "Mid_sampling_run_1",
  "31"  = "Mid_sampling_run_2",
  "32"  = "Mid_sampling_run_3",
  "33"  = "Mid_sampling_run_4",
  "34"  = "Mid_sampling_run_5",
  "35"  = "Mid_sampling_run_6",
  "36"  = "Mid_sampling_run_7",
  "37"  = "Mid_sampling_run_8",
  "38"  = "Mid_sampling_run_9",
  "39"  = "Mid_sampling_run_10",
  "10"  = "Chamber_1_2_mins_mid_sampling_start",
  "11"  = "Chamber_2_2_mins_mid_sampling_start",
  "12"  = "Chamber_3_2_mins_mid_sampling_start",
  "13"  = "Chamber_4_2_mins_mid_sampling_start",
  "14"  = "Chamber_5_2_mins_mid_sampling_start",
  "50"  = "Chamber_1_not_opened_raio_timeout_no_communication",
  "51"  = "Chamber_2_not_opened_raio_timeout_no_communication",
  "52"  = "Chamber_3_not_opened_raio_timeout_no_communication",
  "53"  = "Chamber_4_not_opened_raio_timeout_no_communication",
  "54"  = "Chamber_5_not_opened_raio_timeout_no_communication",
  "20"  = "Chamber_1_sucessfully_opened",
  "21"  = "Chamber_2_sucessfully_opened",
  "22"  = "Chamber_3_sucessfully_opened",
  "23"  = "Chamber_4_sucessfully_opened",
  "24"  = "Chamber_5_sucessfully_opened"
)

# Start cluster
n_cores <- detectCores() - 1
cl <- makeCluster(n_cores)

# Fix for NULL values without using %||%
clusterExport(cl, varlist = c("Valve_data", "code_map"))

mapped_values <- parLapply(cl, Valve_data[, 4], function(code) {
  value <- code_map[as.character(code)]
  if (is.null(value)) NA else value
})

# Stop cluster
stopCluster(cl)

# Apply mapped text to Valve_data column 6
Valve_data[, 6] <- unlist(mapped_values)







#labeling the LGR data with a chamber number######

cl <- makeCluster(detectCores() - 1)
clusterExport(cl, varlist = c("Valve_data", "figure_data1"))

process_valve_row <- function(i) {
  chamber_code <- as.character(Valve_data[i, 4])
  time1 <- Valve_data[i, 5]
  
  if (chamber_code %in% c("10", "11", "12", "13", "14")) {
    chamber_index <- as.numeric(chamber_code) - 9  # Converts 10–14 to 1–5
    
    # Adjust only for chambers 3, 4, 5
    if (chamber_index >= 3) {
      correction_seconds <- (chamber_index - 2) * 20  # Chamber 3 → 5 sec, 4 → 10, 5 → 15
    } else {
      correction_seconds <- 0
    }
    
    adjusted_start <- time1 - correction_seconds
    adjusted_end <- adjusted_start + 120
    
    match_idx <- which(figure_data1[, 33] >= adjusted_start & figure_data1[, 33] <= adjusted_end)
    
    if (length(match_idx) > 0) {
      chamber_label <- paste0("Chamber_", chamber_index)
      return(data.frame(index = match_idx, label = chamber_label))
    }
  }
  
  return(NULL)
}

results <- parLapply(cl, 1:nrow(Valve_data), process_valve_row)
stopCluster(cl)

results <- do.call(rbind, results)

if (!is.null(results)) {
  figure_data1[results$index, 35] <- results$label
}

#plot to view the time synchrony

ggplot(data=na.omit(figure_data1), aes(x=datetime, y=CO2))+
  geom_point(aes(color = V35), size = 1.5, fill = "white", shape = 21, stroke = 1)+
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "35 mins")+
  scale_color_manual(name = "   Chamber ID:  ", labels = c("One", "Two", "Three", "Four", "Five"), values = sub_pallett)+
  scale_y_continuous(
    breaks = seq(min(200), 450, length.out = 5),  # Set the upper limit to 80
    limits = c(min(180), 450),                    # Force the y-axis to extend up to 80
    labels = scales::label_number(accuracy = 1)
  ) +
  xlab("Time (24 hour clock)") +
  ylab(expression(bold("CO"[2]*" Concentration (ppm)")))+
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12) ,
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10, face = "bold"),  # Bold x-axis label
    axis.title.y = element_text(size = 10),
    legend.position = "right")






#adding incubation labels####

Alarms <- subset(Valve_data, code=="30" ,
                 select=datetime:V6)

rownames(Alarms) <- NULL

Time_stamp_1<-Alarms[1, 5]
Time_stamp_2<-Alarms[2, 5]
Time_stamp_3<-Alarms[3, 5]
Time_stamp_4<-Alarms[4, 5]
Time_stamp_5<-Alarms[5, 5]
Time_stamp_6<-Alarms[6, 5]
Time_stamp_7<-Alarms[7, 5]
Time_stamp_8<-Alarms[8, 5]
Time_stamp_9<-Alarms[9, 5]


rows_numbers_LGR<-(NROW(figure_data1))


for(x in 1:(rows_numbers_LGR)) { 
  
  if (isTRUE(figure_data1[x,33]>=Time_stamp_1) && (figure_data1[x,33]<=Time_stamp_2)) {
    
    figure_data1[x,36] <- "Incubation_1"
    
  }
  
  
  if (isTRUE(figure_data1[x,33]>=Time_stamp_2) && (figure_data1[x,33]<=Time_stamp_3)) {
    
    figure_data1[x,36] <- "Incubation_2"
    
  }
  
  if (isTRUE(figure_data1[x,33]>=Time_stamp_3) && (figure_data1[x,33]<=Time_stamp_4)) {
    
    figure_data1[x,36] <- "Incubation_3"
    
  }
  
  if (isTRUE(figure_data1[x,33]>=Time_stamp_4) && (figure_data1[x,33]<=Time_stamp_5)) {
    
    figure_data1[x,36] <- "Incubation_4"
    
  }
  
  if (isTRUE(figure_data1[x,33]>=Time_stamp_5) && (figure_data1[x,33]<=Time_stamp_6)) {
    
    figure_data1[x,36] <- "Incubation_5"
    
  }
  
  if (isTRUE(figure_data1[x,33]>=Time_stamp_6) && (figure_data1[x,33]<=Time_stamp_7)) {
    
    figure_data1[x,36] <- "Incubation_6"
    
  }
  
  if (isTRUE(figure_data1[x,33]>=Time_stamp_7) && (figure_data1[x,33]<=Time_stamp_8)) {
    
    figure_data1[x,36] <- "Incubation_7"
    
  }
  
  if (isTRUE(figure_data1[x,33]>=Time_stamp_8) && (figure_data1[x,33]<=Time_stamp_9)) {
    
    figure_data1[x,36] <- "Incubation_8"
    
  }
  
  if (isTRUE(figure_data1[x,33]>=Time_stamp_9)) {
    
    figure_data1[x,36] <- "Incubation_9"
    
  }
  
}




figure_data1$Time3<-((figure_data1$Time3)-152) 


#fixing labeling to consider that the desiccant label periods increase in time as the chambers iterate from 1 to 5 ######

#mid code labeling preventing overlaps #####

# Setup cluster
n_cores <- detectCores() - 1
cl <- makeCluster(n_cores)

# Vector of valve codes and corresponding mid-run labels
valve_ids <- as.character(30:39)
mid_run_labels <- paste0("Mid_run_", 1:10)
valve_mapping <- setNames(mid_run_labels, valve_ids)

# Export necessary variables and mapping
clusterExport(cl, varlist = c("Valve_data", "figure_data1", "valve_mapping"))

# Define processing function
process_valve <- function(valve_code) {
  local_fig_data <- figure_data1
  local_valve_data <- Valve_data
  label <- valve_mapping[valve_code]
  
  # Store updates in a vector
  updates <- rep(NA, nrow(local_fig_data))
  
  match_idx <- which(local_valve_data[, 4] == valve_code)
  
  for (i in match_idx) {
    # Safety check to avoid going out of bounds
    if (i + 6 > nrow(local_valve_data)) next
    
    Time_stamp_1 <- local_valve_data[i, 5]
    Time_stamp_2 <- local_valve_data[i + 6, 5]
    
    idx <- which(local_fig_data[, 33] >= Time_stamp_1 & local_fig_data[, 33] <= Time_stamp_2)
    updates[idx] <- label
  }
  
  return(updates)  # NA everywhere except new labels
}

# Run in parallel
results <- parLapply(cl, valve_ids, process_valve)

# Stop cluster
stopCluster(cl)

# Combine updates, prioritizing earlier codes (e.g. "30" over "39")
combined_updates <- rep(NA, nrow(figure_data1))
for (res in results) {
  overwrite_idx <- which(!is.na(res) & is.na(combined_updates))
  combined_updates[overwrite_idx] <- res[overwrite_idx]
}

# Apply updates to figure_data1
figure_data1[, 37] <- combined_updates








#extracting the measurement data #######


# Create column to store Run_name in figure_data1
figure_data1$Run_name <- NA

# Define function to process each chamber
process_chamber <- function(ii) {
  Incubation <- subset(figure_data1, V35 == paste0("Chamber_", ii), select = Month:V37)
  rownames(Incubation) <- NULL
  rows_numbers_LGR <- NROW(na.omit(Incubation))
  
  chamber_run_number <- 0
  Rate_extractions_file <- data.frame()
  incubation_runs <- list()
  
  start_run <- 2
  end_run <- 1
  Incubation_number <- 0
  
  for (x in 2:(rows_numbers_LGR)) {
    if ((Incubation[x,37] == Incubation[x + 1, 37]) && (Incubation[x,37] != Incubation[x - 1, 37])) {
      start_run <- x
    }
    
    if (x == nrow(Incubation) || ((Incubation[x, 37] != Incubation[x + 1, 37]) && (Incubation[x, 37] == Incubation[x - 1, 37]))) {
      end_run <- x
      
      # Extract and clean data
      day_2 <- data.frame(Incubation[start_run:end_run, ])
      rownames(day_2) <- NULL
      rows_numbers <- NROW(na.omit(day_2))
      day_2$V38 <- ifelse(seq_len(rows_numbers) < 60 | seq_len(rows_numbers) > 110, "Cut", "Keep")
      
      # Crop to main run
      day_3 <- day_2[60:110, ]
      seconds_offset_to_zero <- day_3[1,33]
      day_3$Seconds1 <- day_3[,33] - seconds_offset_to_zero
      
      # Fit models
      b_reg <- lm(CO2 ~ Seconds1, data = day_3)
      b_coeff <- coefficients(b_reg)
      b_Diffusion_fit <- summary(b_reg)$r.squared
      
      a_reg <- lm(CH4 ~ Seconds1, data = day_3)
      a_coeff <- coefficients(a_reg)
      a_Diffusion_fit <- summary(a_reg)$r.squared
      
      bubble <- a_Diffusion_fit < 0.99
      
      if (bubble) {
        bubble_data <- rbind(day_3[1, ], day_3[nrow(day_3), ])
        a_reg <- lm(CH4 ~ Seconds1, data = bubble_data)
        a_coeff <- coefficients(a_reg)
      }
      
      nam <- paste0("chamber_", ii, "_run_", chamber_run_number)
      day_3$Run_name <- nam
      incubation_runs[[chamber_run_number + 1]] <- day_3
      
      # Update figure_data1 with Run_name
      match_rows <- which(figure_data1$datetime %in% day_3$datetime)
      figure_data1$Run_name[match_rows] <- nam
      
      # Save summary row
      new_row <- data.frame(
        Run_name = nam,
        Month = Incubation[x + 1, 1],
        Day = Incubation[x + 1, 2],
        Year = Incubation[x + 1, 3],
        Time1 = Incubation[x + 1, 4],
        datetime = Incubation[x + 1, 32],
        X.CH4._ppm = Incubation[x + 1, 5],
        V35 = Incubation[x + 1, 35],
        V36 = Incubation[x + 1, 36],
        V37 = Incubation[x + 1, 37],
        Ebullition = bubble,
        CH4_Fit_ie_Rsquared = a_Diffusion_fit,
        CO2_Fit_ie_Rsquared = b_Diffusion_fit,
        CH4_rate_m = round(a_coeff[2], 5),
        CO2_rate_m = round(b_coeff[2], 5),
        CH4_intercept_c = round(a_coeff[1], 2),
        CO2_intercept_c = round(b_coeff[1], 2)
      )
      
      Rate_extractions_file <- rbind(Rate_extractions_file, new_row)
      chamber_run_number <- chamber_run_number + 1
    }
  }
  
  # Combine and adjust time
  combined <- do.call(rbind, incubation_runs)
  combined$Total_Mins <- combined$Total_Mins * 60 - 4261
  
  list(data = combined, summary = Rate_extractions_file, updated_fig_data = figure_data1)
}

# Parallel setup
cl <- makeCluster(5)
clusterExport(cl, varlist = c("figure_data1", "fantastic"))
clusterEvalQ(cl, {
  library(ggplot2)
  library(cowplot)
})

# Run the function for all chambers
results <- parLapply(cl, 1:5, process_chamber)
stopCluster(cl)

# Combine results
all_chambers <- do.call(rbind, lapply(results, function(res) res$data))
Rate_extractions_file <- do.call(rbind, lapply(results, function(res) res$summary))

# Restore Run_name into figure_data1 from updated copies
updated_figs <- lapply(results, function(res) res$updated_fig_data)
figure_data1$Run_name <- Reduce(function(a, b) ifelse(is.na(a), b, a), lapply(updated_figs, `[[`, "Run_name"))

# Final arrangement
all_chambers <- all_chambers[order(all_chambers$datetime), ]
rownames(all_chambers) <- NULL



figure_data1<-figure_data1[order(figure_data1$datetime), ]
rownames(figure_data1) <- NULL

# plot data 

ggplot(data=na.omit(figure_data1), aes(x=datetime, y=CO2))+
  geom_point(aes(color = Run_name), size = 1.5, fill = "white", shape = 21, stroke = 1)+
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "35 mins")+
  xlab("Time (24 hour clock)") +
  ylab(expression(bold("CO"[2]*" Concentration (ppm)")))+
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12) ,
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10, face = "bold"),  # Bold x-axis label
    axis.title.y = element_text(size = 10),
    legend.position = "none")

ggplot(data=na.omit(figure_data1), aes(x=datetime, y=CH4))+
  geom_point(aes(color = Run_name), size = 1.5, fill = "white", shape = 21, stroke = 1)+
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "35 mins")+
  xlab("Time (24 hour clock)") +
  ylab(expression(bold("CO"[2]*" Concentration (ppm)")))+
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12) ,
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10, face = "bold"),  # Bold x-axis label
    axis.title.y = element_text(size = 10),
    legend.position = "none")





ggplot(data=na.omit(all_chambers), aes(x=datetime, y=CO2))+
  geom_point(aes(color = V35), size = 1.5, fill = "white", shape = 21, stroke = 1)+
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "35 mins")+
  scale_color_manual(name = "   Chamber ID:  ", labels = c("One", "Two", "Three", "Four", "Five"), values = sub_pallett)+
  xlab("Time (24 hour clock)") +
  ylab(expression(bold("CO"[2]*" Concentration (ppm)")))+
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12) ,
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10, face = "bold"),  # Bold x-axis label
    axis.title.y = element_text(size = 10),
    legend.position = "right")


ggplot(data=na.omit(all_chambers), aes(x=datetime, y=CH4))+
  geom_point(aes(color = V35), size = 1.5, fill = "white", shape = 21, stroke = 1)+
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "35 mins")+
  scale_color_manual(name = "   Chamber ID:  ", labels = c("One", "Two", "Three", "Four", "Five"), values = sub_pallett)+
  xlab("Time (24 hour clock)") +
  ylab(expression(bold("CO"[2]*" Concentration (ppm)")))+
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12) ,
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10, face = "bold"),  # Bold x-axis label
    axis.title.y = element_text(size = 10),
    legend.position = "right")





#extracting flux in mg m-2 day-1 #######

# Constants
R <- 8.3143             # J/(mol*K)
A <- 0.09621127502      # m^2
V <- 0.02675            # m^3
M_CH4 <- 16             # g/mol
M_CO2 <- 44             # g/mol

# Initialize data frame
overall_incubation_rates <- data.frame()

# Get unique combinations of chambers and incubations
unique_combinations <- all_chambers %>%
  select(V35, V36) %>%
  distinct()

# Loop over combinations
for (i in 1:nrow(unique_combinations)) {
  chamber <- unique_combinations$V35[i]
  incubation <- unique_combinations$V36[i]
  
  subset_data <- all_chambers %>%
    filter(V35 == chamber, V36 == incubation) %>%
    arrange(datetime)
  
  if (nrow(subset_data) < 2) next
  
  # Linear models
  co2_model <- lm(CO2 ~ datetime, data = subset_data)
  ch4_model <- lm(CH4 ~ datetime, data = subset_data)
  
  co2_r_squared <- summary(co2_model)$r.squared
  co2_slope <- coef(co2_model)[2]
  co2_intercept <- coef(co2_model)[1]
  
  ch4_r_squared <- summary(ch4_model)$r.squared
  ch4_slope <- coef(ch4_model)[2]
  ch4_intercept <- coef(ch4_model)[1]
  
  bubble_detected <- ch4_r_squared < 0.99
  
  if (bubble_detected) {
    ch4_model <- lm(CH4 ~ datetime, data = subset_data[c(1, nrow(subset_data)), ])
    ch4_r_squared <- summary(ch4_model)$r.squared
    ch4_slope <- coef(ch4_model)[2]
    ch4_intercept <- coef(ch4_model)[1]
  }
  
  # Get temperature and pressure (mean or first row)
  temp_c <- mean(subset_data$GasT_C, na.rm = TRUE)
  pressure_pa <- mean(subset_data$GasP_torr, na.rm = TRUE)
  temp_k <- temp_c + 273.15
  
  # Convert slopes (ppm/s) to fluxes (mass per area per time)
  CH4_mg_m_d <- ch4_slope * ((V * pressure_pa) / (A * R * temp_k)) * 1e-6 * 86400 * 1e3 * M_CH4
  CO2_mg_m_d <- co2_slope * ((V * pressure_pa) / (A * R * temp_k)) * 1e-6 * 86400 * 1e3 * M_CO2
  
  # Store results
  result_row <- data.frame(
    Chamber = chamber,
    Incubation = incubation,
    datetime = subset_data$datetime[nrow(subset_data)],
    CO2_Slope = co2_slope,
    CO2_Intercept = co2_intercept,
    CO2_R_Squared = co2_r_squared,
    CH4_Slope = ch4_slope,
    CH4_Intercept = ch4_intercept,
    CH4_R_Squared = ch4_r_squared,
    Bubble_Detected = bubble_detected,
    CH4_mg_m_d = CH4_mg_m_d,
    CO2_mg_m_d = CO2_mg_m_d
  )
  
  overall_incubation_rates <- rbind(overall_incubation_rates, result_row)
  
  # Create the plot
  plot_co2 <- ggplot(subset_data, aes(x = datetime)) +
    geom_point(aes(y = CO2, color = "CO2")) +
    geom_abline(slope = co2_slope, intercept = co2_intercept, color = "blue", linetype = "dashed") +
    labs(title = paste("Chamber:", chamber, "| Incubation:", incubation),
         y = "Gas Concentration (ppm)",
         color = "Gas") +
    theme(
      panel.background = element_rect(fill = "white", colour = "white"),
      panel.grid = element_blank(),
      axis.line = element_line(color = "black"),
      legend.background = element_rect(fill = "white"),
      legend.title = element_text(size = 12),
      legend.key.size = unit(2, "lines"),
      legend.text = element_text(size = 12),
      plot.title = element_text(size = 10, face = "bold"),
      axis.text.x = element_text(size = 10),
      axis.text.y = element_text(size = 10),
      axis.title.x = element_text(size = 10, face = "bold"),
      axis.title.y = element_text(size = 10)
    ) 
  
  plot_ch4 <- ggplot(subset_data, aes(x = datetime)) +
    geom_point(aes(y = CH4, color = "CH4")) +
    geom_abline(slope = ch4_slope, intercept = ch4_intercept, color = "red", linetype = "dotted") +
    labs(title = paste("Chamber:", chamber, "| Incubation:", incubation),
         y = "Gas Concentration (ppm)",
         color = "Gas") +
    theme(
      panel.background = element_rect(fill = "white", colour = "white"),
      panel.grid = element_blank(),
      axis.line = element_line(color = "black"),
      legend.background = element_rect(fill = "white"),
      legend.title = element_text(size = 12),
      legend.key.size = unit(2, "lines"),
      legend.text = element_text(size = 12),
      plot.title = element_text(size = 10, face = "bold"),
      axis.text.x = element_text(size = 10),
      axis.text.y = element_text(size = 10),
      axis.title.x = element_text(size = 10, face = "bold"),
      axis.title.y = element_text(size = 10)
    )
  
  combined_plot<-plot_grid(plot_co2, plot_ch4, ncol = 1, rel_heights = c(1, 1))
  
  # Save the plot
  ggsave(filename = paste0("plot_", chamber, "_", incubation, ".png"), plot = combined_plot, width = 8, height = 6)
}

# View the results
print(overall_incubation_rates)



plot_data_123 <- subset(overall_incubation_rates, Incubation != "Incubation_9")

ggplot(data=(plot_data_123), aes(x=datetime, y=CH4_mg_m_d))+
  geom_point(aes(color = Chamber), size = 3, fill = "white", shape = 21, stroke = 1)+
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "4 hours")+
  scale_color_manual(name = "   Chamber ID:  ", labels = c("One", "Two", "Three", "Four", "Five"), values = sub_pallett)+
  scale_y_continuous(
    trans = 'log10',
  ) +
  xlab("Time (24 hour clock)") +
  ylab(expression(bold("CH"[4] * " flux rate (mg  " * m^{-2} * " d"^{-1} * ")")))+
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12) ,
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10, face = "bold"),  # Bold x-axis label
    axis.title.y = element_text(size = 10),
    legend.position = "right")



ggplot(data=(plot_data_123), aes(x=datetime, y=CO2_mg_m_d))+
  geom_point(aes(color = Chamber), size = 3, fill = "white", shape = 21, stroke = 1)+
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "3 hours")+
  scale_color_manual(name = "   Chamber ID:  ", labels = c("One", "Two", "Three", "Four", "Five"), values = sub_pallett)+
  scale_y_continuous(
    breaks = seq(min(-0.6), -0.1, length.out = 5),  # Set the upper limit to 80
    labels = scales::label_number(accuracy = 0.1)
  ) +
  xlab("Time (24 hour clock)") +
  ylab(expression(bold("CO"[2] * " flux rate (mg  " * m^{-2} * " d"^{-1} * ")")))+
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12) ,
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10, face = "bold"),  # Bold x-axis label
    axis.title.y = element_text(size = 10),
    legend.position = "right")





ggplot(data = plot_data_123, aes(x = datetime, y = CH4_mg_m_d)) +
  geom_point(aes(color = Chamber), size = 3, fill = "white", shape = 21, stroke = 1) +
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "4 hours") +
  scale_color_manual(
    name = "   Chamber ID:  ",
    labels = c("One", "Two", "Three", "Four", "Five"),
    values = sub_pallett
  ) +
  scale_y_continuous(
    trans = "log10",
    breaks = c(0.001, 0.0032, 0.01, 0.0178, 0.0316),  # approx log-spaced values
    labels = scales::label_number(accuracy = 0.001)
  )+
  xlab("Time (24 hour clock)") +
  ylab(expression(bold("CH"[4] * " flux rate (mg " * m^{-2} * " d"^{-1} * ")"))) +
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12),
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10, face = "bold"),
    axis.title.y = element_text(size = 10),
    legend.position = "right"
  )





#creating figures #####

#Part A #####

background_vent_cycle<- data.frame(start = c(figure_data1$datetime[35138], figure_data1$datetime[46748]),  # Create data with breaks
                            end = c(figure_data1$datetime[37591], figure_data1$datetime[49208]),
                            colors = as.factor(c(1,1)))





#data_breaks   

a<- ggplot() +                                        # Add background colors to plot
  geom_rect(data = background_vent_cycle,
            aes(xmin = start,
                xmax = end,
                ymin = - Inf,
                ymax = Inf,
                fill = colors),
            alpha = 0.5, 
            show.legend = FALSE) +
  scale_fill_manual(values = c("lightgrey"))+ 
  
  geom_point(
    data = na.omit(all_chambers[5101:12750, ]),
    aes(x = datetime, y = CO2, color = V35),
    size = 1.5, fill = "white", shape = 21, stroke = 1
  )+
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "90 mins")+
  scale_color_manual(name = "   Chamber ID:  ", labels = c("One", "Two", "Three", "Four", "Five"), values = sub_pallett)+
  scale_y_continuous(
   breaks = seq(min(350), 450, length.out = 5),  # Set the upper limit to 80
   limits = c(min(340), 450),                    # Force the y-axis to extend up to 80
   labels = scales::label_number(accuracy = 1)
   ) +
  xlab("Time (24 hour clock)") +
  ylab(expression(bold("CO"[2]*" Concentration (ppm)")))+
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12) ,
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10, face = "bold"),  # Bold x-axis label
    axis.title.y = element_text(size = 10, margin = margin(r = 15)),
    legend.position = "right")

figure_a<- a + theme(legend.position = "none")
figure_a_legend <- get_legend(a) #use plot(legend) to view



#Part B #####


#model ch4
Chamber_1__ <- subset(all_chambers, V35 == "Chamber_1" & V36 == "Incubation_3")
a_reg<-lm(CO2 ~ datetime, data = Chamber_1__)
a_coeff=coefficients(a_reg)
a_coeff_df<-(data.frame(a_coeff))
a_intercept<-(a_coeff_df[1,])
a_slope<-(a_coeff_df[2,])
a_Diffusion_fit<-summary(a_reg)$r.squared

Chamber_2__ <- subset(all_chambers, V35 == "Chamber_2" & V36 == "Incubation_3")
b_reg<-lm(CO2 ~ datetime, data = Chamber_2__)
b_coeff=coefficients(b_reg)
b_coeff_df<-(data.frame(b_coeff))
b_intercept<-(b_coeff_df[1,])
b_slope<-(b_coeff_df[2,])
b_Diffusion_fit<-summary(b_reg)$r.squared

Chamber_3__ <- subset(all_chambers, V35 == "Chamber_3" & V36 == "Incubation_3")
c_reg<-lm(CO2 ~ datetime, data = Chamber_3__)
c_coeff=coefficients(c_reg)
c_coeff_df<-(data.frame(c_coeff))
c_intercept<-(c_coeff_df[1,])
c_slope<-(c_coeff_df[2,])
c_Diffusion_fit<-summary(c_reg)$r.squared

Chamber_4__ <- subset(all_chambers, V35 == "Chamber_4" & V36 == "Incubation_3")
d_reg<-lm(CO2 ~ datetime, data = Chamber_4__)
d_coeff=coefficients(d_reg)
d_coeff_df<-(data.frame(d_coeff))
d_intercept<-(d_coeff_df[1,])
d_slope<-(d_coeff_df[2,])
d_Diffusion_fit<-summary(d_reg)$r.squared

Chamber_5__ <- subset(all_chambers, V35 == "Chamber_5" & V36 == "Incubation_3")
e_reg<-lm(CO2 ~ datetime, data = Chamber_5__)
e_coeff=coefficients(e_reg)
e_coeff_df<-(data.frame(e_coeff))
e_intercept<-(e_coeff_df[1,])
e_slope<-(e_coeff_df[2,])
e_Diffusion_fit<-summary(e_reg)$r.squared


part_b_data<-subset(all_chambers, V36 == "Incubation_3")


# Create a dataframe of slopes, intercepts, and corresponding chambers
abline_data <- data.frame(
  intercept = c(a_intercept, b_intercept, c_intercept, d_intercept, e_intercept),
  slope = c(a_slope, b_slope, c_slope, d_slope, e_slope),
  V35 = factor(c("Chamber_1", "Chamber_2", "Chamber_3", "Chamber_4", "Chamber_5"))
)

# Main plot
b <- ggplot() +
  geom_point(
    data = na.omit(part_b_data),
    aes(x = datetime, y = CO2, color = V35),
    size = 1.5, fill = "white", shape = 21, stroke = 1
  ) +
  geom_abline(
    data = abline_data,
    aes(intercept = intercept, slope = slope, color = V35),
    linetype = "solid"
  ) +
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "30 mins") +
  scale_color_manual(
    name = "   Chamber ID:  ",
    labels = c("One", "Two", "Three", "Four", "Five"),
    values = sub_pallett
  ) +
  scale_y_continuous(
    breaks = seq(min(350), 450, length.out = 5),
    limits = c(min(340), 450),
    labels = scales::label_number(accuracy = 1)
  ) +
  xlab("Time (24 hour clock)") +
  ylab(expression(bold("CO"[2]*" Concentration (ppm)"))) +
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12),
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10, face = "bold"),
    axis.title.y = element_text(size = 10, margin = margin(r = 15)),
    legend.position = "right"
  )

b

figure_b<- b + theme(legend.position = "none")
figure_b_legend <- get_legend(b) #use plot(legend) to view


#Part C - log scale no abline#####

#model ch4
Chamber_1__ <- subset(all_chambers, V35 == "Chamber_1" & V36 == "Incubation_6")
Chamber_1__ <- rbind(head(Chamber_1__, 1), tail(Chamber_1__, 1))
a_reg<-lm(CH4 ~ datetime, data = Chamber_1__)
a_coeff=coefficients(a_reg)
a_coeff_df<-(data.frame(a_coeff))
a_intercept<-(a_coeff_df[1,])
a_slope<-(a_coeff_df[2,])
a_Diffusion_fit<-summary(a_reg)$r.squared

Chamber_2__ <- subset(all_chambers, V35 == "Chamber_2" & V36 == "Incubation_6")
b_reg<-lm(CH4 ~ datetime, data = Chamber_2__)
b_coeff=coefficients(b_reg)
b_coeff_df<-(data.frame(b_coeff))
b_intercept<-(b_coeff_df[1,])
b_slope<-(b_coeff_df[2,])
b_Diffusion_fit<-summary(b_reg)$r.squared

Chamber_3__ <- subset(all_chambers, V35 == "Chamber_3" & V36 == "Incubation_6")
c_reg<-lm(CH4 ~ datetime, data = Chamber_3__)
c_coeff=coefficients(c_reg)
c_coeff_df<-(data.frame(c_coeff))
c_intercept<-(c_coeff_df[1,])
c_slope<-(c_coeff_df[2,])
c_Diffusion_fit<-summary(c_reg)$r.squared

Chamber_4__ <- subset(all_chambers, V35 == "Chamber_4" & V36 == "Incubation_6")
d_reg<-lm(CH4 ~ datetime, data = Chamber_4__)
d_coeff=coefficients(d_reg)
d_coeff_df<-(data.frame(d_coeff))
d_intercept<-(d_coeff_df[1,])
d_slope<-(d_coeff_df[2,])
d_Diffusion_fit<-summary(d_reg)$r.squared

Chamber_5__ <- subset(all_chambers, V35 == "Chamber_5" & V36 == "Incubation_6")
e_reg<-lm(CH4 ~ datetime, data = Chamber_5__)
e_coeff=coefficients(e_reg)
e_coeff_df<-(data.frame(e_coeff))
e_intercept<-(e_coeff_df[1,])
e_slope<-(e_coeff_df[2,])
e_Diffusion_fit<-summary(e_reg)$r.squared


part_b_data<-subset(all_chambers, V36 == "Incubation_6")


# Create a dataframe of slopes, intercepts, and corresponding chambers
abline_data <- data.frame(
  intercept = c(a_intercept, b_intercept, c_intercept, d_intercept, e_intercept),
  slope = c(a_slope, b_slope, c_slope, d_slope, e_slope),
  V35 = factor(c("Chamber_1", "Chamber_2", "Chamber_3", "Chamber_4", "Chamber_5"))
)

# Main plot
b <- ggplot() +
  geom_point(
    data = na.omit(part_b_data),
    aes(x = datetime, y = CH4, color = V35),
    size = 1.5, fill = "white", shape = 21, stroke = 1
  ) +
  geom_abline(
    data = abline_data,
    aes(intercept = intercept, slope = slope, color = V35),
    linetype = "solid"
  ) +
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "30 mins") +
  scale_color_manual(
    name = "   Chamber ID:  ",
    labels = c("One", "Two", "Three", "Four", "Five"),
    values = sub_pallett
  ) +
  scale_y_continuous(
    trans = 'log10',
    breaks = seq(min(2.5), 11, length.out = 5),
    #limits = c(min(340), 450),
    labels = scales::label_number(accuracy = 1)
  ) +
  xlab("Time (24 hour clock)") +
  ylab(expression(bold("CH"[4]*" Concentration (ppm)"))) +
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12),
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10, face = "bold"),
    axis.title.y = element_text(size = 10),
    legend.position = "right"
  )

b


figure_c<- b + theme(legend.position = "none")
figure_c_legend <- get_legend(b) #use plot(legend) to view


#Part D - overall rates in mg  #####

d <- ggplot(data = plot_data_123, aes(x = datetime, y = CH4_mg_m_d)) +
  geom_point(aes(color = Chamber), size = 1.5, fill = "white", shape = 21, stroke = 1) +
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "4 hours") +
  scale_color_manual(
    name = "   Chamber ID:  ",
    labels = c("One", "Two", "Three", "Four", "Five"),
    values = sub_pallett
  ) +
  scale_y_continuous(
    trans = "log10",
    breaks = c(0.001, 0.0032, 0.01, 0.0178, 0.0316),  # approx log-spaced values
    labels = scales::label_number(accuracy = 0.001)
  )+
  xlab("Time (24 hour clock)") +
  ylab(expression(bold("CH"[4] * " flux (mg " * m^{-2} * " d"^{-1} * ")"))) +
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12),
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10, face = "bold"),
    axis.title.y = element_text(size = 10),
    legend.position = "right"
  )

d

figure_d<- d + theme(legend.position = "none")
figure_d_legend <- get_legend(d) #use plot(legend) to view


#Final plot1 #####


middle_row <- plot_grid(figure_b, figure_c, ncol = 2)  # Top row: p1 and p2 side by side
final_plot <- plot_grid(figure_a, middle_row, figure_d, ncol = 1, rel_heights = c(1, 1))  # Combine rows

# Display the plot
final_plot






#save plot

ggsave("Figure_4.png", width = 140, height = 175, units = "mm") #saving the graph to the file directory


final_plot


#dev.off()
(while (!is.null(dev.list()))  dev.off())   




#save figure a legend
ggsave("figure_4_legend.png", plot = figure_a_legend, width = 50, height = 70, units = "mm")

#dev.off()
(while (!is.null(dev.list()))  dev.off()) 



