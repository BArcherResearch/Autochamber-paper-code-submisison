This folder creates Figures 5 and 6:

Figure 5:
CO2 flux measurements from a chamber deployed in an urban pond using the internal-sensor method for stand-alone deployments. a) CO2 concentrations measured using a Los Gatos Ultraportable analyser plotted against CO2 concentrations measured using a Sensirion SCD30 CO2 sensor. b) Residual plot illustrating the accuracy of the Sensirion SCD30 sensor in predicting CO2 concentration. c) Comparison of CO2 concentrations measured using a Los Gatos Ultraportable (black circles) and a Sensirion SCD30 sensor (orange circles) over a 13-h deployment period. Each gradient indicates the flux of CO2 across the air water interface during an individual chamber measurement cycle.

Figure 6:
CH4 fluxes in an urban pond measured using the internal-sensor method for stand-alone deployments. a) Observed CH4 concentrations measured using a Los Gatos Ultraportable plotted against predicted CH4 concentrations after Figaro sensor model calibration. b) Residual plot indicating the accuracy of the Figaro sensor calibration model in predicting CH4 concentration. c) Comparison of the predictor variables used to model the Figaro sensor CH4 response, where yellow points represent relative humidity and purple points represent temperature. d) Comparison of the observed CH4 concentrations measured using a Los Gatos Ultraportable (black circles) and a calibrated Figaro CH4 sensor measurements (orange circles) over time. Each gradient indicates the flux of CH4 across the air-water interface during a chamber measurement cycle. The measurement cycle before last (at 07:15 h) is an example of an ebullition event.


R version 4.3.0 is used.

The script isolates the measurement data from non-measurement data and plots it ready for publication. 
