#Figure 5 and 6 publication figure


#housekeeping######
if (!require(readxl)) install.packages('readxl')
library(readxl)

if (!require(tidyr)) install.packages('tidyr')
library(tidyr)

if (!require(dplyr)) install.packages('dplyr')
library(dplyr)

if (!require(wesanderson)) install.packages('wesanderson')
library(wesanderson)

if (!require(chron)) install.packages('chron')
library(chron)

if (!require(cowplot)) install.packages('cowplot')
library(cowplot)

if (!require(stats)) install.packages('stats')
library(stats)

if (!require(ggplot2)) install.packages('ggplot2')
library(ggplot2)

if (!require(lubridate)) install.packages('lubridate')
library(lubridate)

if (!require(viridis)) install.packages('viridis')
library(viridis)

# Install the minpack.lm package if necessary
if (!require(minpack.lm)) install.packages('minpack.lm')
library(minpack.lm)

full_pallett<-viridis_pal(option = "B")(10)

#importing the data set, tidying the data set, and looking at the whole overview######

day_1<-read.delim2("LGR_Data/My_analyser/2022-08-30/gga_2022-08-30_f0000.txt", header = TRUE, sep = ",", dec = ".")
day_2<-read.delim2("LGR_Data/My_analyser/2022-08-31/gga_2022-08-31_f0000.txt", header = TRUE, sep = ",", dec = ".")
hour.1<- rbind(day_1, day_2)


#changing colum titles
names(hour.1)[names(hour.1) == "X.CH4._ppm"] <- "CH4"
names(hour.1)[names(hour.1) == "X.CO2._ppm"] <- "CO2"
names(hour.1)[names(hour.1) == "X.H2O._ppm"] <- "H2O"

#creating new time column

hour.1<-separate(data = hour.1, col = Time, into = c("Month", "Day", "Year"), sep = "/")

hour.1<-separate(data = hour.1, col = Year, into = c("Year", "Time1"), sep = " ")

hour.1$Time2<-as.times(hour.1$Time1)

hour.1$Time3<-(hour.1$Time2)

hour.1<-separate(data = hour.1, col = Time3, into = c("Hours", "Minutes", "Seconds"), sep = ":")

hour.1$datetime<-ymd_hms(paste(hour.1$Year, hour.1$Month, hour.1$Day, hour.1$Time2, sep="-"))

hour.1$Time3<-as.numeric(hour.1$datetime)

seconds_offset_to_zero<-(hour.1[1,33])
seconds_offset_to_zero #check it is the first value for Time1
rows_numbers<-(NROW(na.omit(hour.1)))
rows_numbers

hour.1 <- na.omit(hour.1)



for(i in 1:(rows_numbers)) {                                    #setting the seconds to 0 based upon the date
  
  hour.1[(i),34]<-((hour.1[(i),33])-seconds_offset_to_zero)
  
}


names(hour.1)[34] <- "Total_Mins"                                     #converting column 26 to minutes of experiment from 0

hour.1$Total_Mins<-((hour.1$Total_Mins)/60)





#quick overview
###date-time x axis###

first_look_co2<- ggplot(data=hour.1, aes(x=datetime, y=CO2))+
  geom_point()+
  # geom_point(aes(color = V35))+
  scale_x_datetime(date_breaks = "5 hours")+
  
  xlab("Time (Minutes)") +
  ylab(expression ("CO"[2]*" Concentration (ppm)"))+
  theme(text = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        plot.title = element_text(size=10))

first_look_co2


first_look_CH4<- ggplot(data=hour.1, aes(x=datetime, y=CH4))+
  scale_y_continuous(trans='log2')+
  scale_x_datetime(date_breaks = "5 hours")+
  geom_point()+
  #geom_point(aes(color = V35))+
  xlab("Time (Date-Time)") +
  # ylab(expression ("CH"[4]*" Concentration (ppm)"))+
  ylab(expression("Log"[2]*" [CH"[4]*" Concentration (ppm)]"))+
  theme(text = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        plot.title = element_text(size=10))

first_look_CH4





#chamber fitted to LGR script

#reading data from the chamber that fits the LGR data  ####

Chamber_data_1<-read.delim2("Chamber_Data/D1/corrected_header_30_8_22.TXT", header = TRUE, sep = ",", dec = ".")
Chamber_data_2<-read.delim2("Chamber_Data/D1/corrected_header_31_8_22.TXT", header = TRUE, sep = ",", dec = ".")


Chamber_data_1<- Chamber_data_1[-c(12) ]
Chamber_data_2<- Chamber_data_2[-c(12) ]
Chamber_data_full<-rbind(Chamber_data_1, Chamber_data_2)



Chamber_data_full$Time<-as.times(Chamber_data_full$Time)

Chamber_data_full<-separate(data = Chamber_data_full, col = Date, into = c("Day", "Month", "Year"), sep = ":")


Chamber_data_full$Date<-ymd(paste(Chamber_data_full$Year, Chamber_data_full$Month, Chamber_data_full$Day, sep="-"))

Chamber_data_full$datetime<-ymd_hms(paste(Chamber_data_full$Date, Chamber_data_full$Time, sep="-"))

Chamber_data_full$Time1<-as.numeric(Chamber_data_full$datetime)

Chamber_data_full$Time1<-((Chamber_data_full$Time1)-3600)

Chamber_data_full$Time2<-as_datetime(Chamber_data_full$Time1)

Chamber_data_full$CH4_3<-abs(Chamber_data_full$CH4_3)

Chamber_data_full$CH4_4<-abs(Chamber_data_full$CH4_4)


first_look_co2<- ggplot(data=Chamber_data_full, aes(x=datetime, y=CO2))+
  geom_point()+
  scale_x_datetime(date_breaks = "5 hours")+
  xlab("Time (Date-Time)") +
  ylab(expression ("CO"[2]*" Concentration (ppm)"))+
  theme(text = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        plot.title = element_text(size=10))

first_look_co2



first_look_CH4<- ggplot(data=Chamber_data_full, aes(x=datetime, y=CH4_3))+
  scale_x_datetime(date_breaks = "5 hours")+
  geom_point()+
  xlab("Time (Date-Time)") +
  ylab(expression ("CH"[4]*" Concentration (Differential mv)"))+
  theme(text = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        plot.title = element_text(size=10))

first_look_CH4



first_look_CH4_1<- ggplot(data=Chamber_data_full, aes(x=datetime, y=CH4_4))+
  scale_x_datetime(date_breaks = "5 hours")+
  geom_point()+
  xlab("Time (Date-Time)") +
  ylab(expression ("CH"[4]*" Concentration (Differential mv)"))+
  theme(text = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        plot.title = element_text(size=10))

first_look_CH4_1





##################

Chamber_data_full$Time1<-as.numeric(Chamber_data_full$datetime-1000)


Chamber_data_full$datetime<-as.numeric(Chamber_data_full$datetime+75)

#removing the chamber first 5 mins for each run ######


#labeling individual runs from the LGR data in conjunction with the chamber file######

# Initialise variables
in_run <- FALSE
Time_stamp_1 <- NA
Time_stamp_2 <- NA

rows_numbers_LGR <- nrow(hour.1)

# Set column 29 to "Open" by default
hour.1[, 35] <- "Open"

# Loop through the rows in Chamber_data_full
for (i in 1:nrow(Chamber_data_full)) {
  if (Chamber_data_full$Comm[i] == 1 && !in_run) {
    # Start of a run
    Time_stamp_1 <- Chamber_data_full$datetime[i]
    in_run <- TRUE
  } else if (Chamber_data_full$Comm[i] == 0 && in_run) {
    # End of a run
    Time_stamp_2 <- Chamber_data_full$datetime[i - 1]
    in_run <- FALSE
    
    # Update "Closed" status in 'test' based on timestamps
    for (s in 1:rows_numbers_LGR) {
      # Ensure test[s,27] falls between Time_stamp_1 and Time_stamp_2
      if (hour.1[s, 32] > Time_stamp_1 && hour.1[s, 32] < Time_stamp_2) {
        hour.1[s, 35] <- "Closed"
      }
    }
  }
}

hour.1$Chamber_Lid<-hour.1$V35



first_look_co2<- ggplot(data=hour.1, aes(x=datetime, y=CO2))+
  geom_point(aes(color = Chamber_Lid))+
  scale_x_datetime(date_breaks = "5 hours")+
  xlab("Time (Minutes)") +
  ylab(expression ("CO"[2]*" Concentration (ppm)"))+
  theme(text = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        plot.title = element_text(size=10))

first_look_co2



first_look_CH4<- ggplot(data=hour.1[48000:74911, ], aes(x=datetime, y=CH4))+
  scale_y_continuous(trans='log2')+
  scale_x_datetime(date_breaks = "5 hours")+
  # geom_point()+
  geom_point(aes(color = Chamber_Lid))+
  xlab("Time (Minutes)") +
  # ylab(expression ("CH"[4]*" Concentration (ppm)"))+
  ylab(expression("Log"[2]*" [CH"[4]*" Concentration (ppm)]"))+
  theme(text = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        plot.title = element_text(size=10))

first_look_CH4



#calibration #######
#run this to do the whole day (excluding the first few hours)

Incubation_only_data <- subset(hour.1, Chamber_Lid=="Closed")

Chamber_data_full$datetime<-as.POSIXct(Chamber_data_full$datetime)

#reset the row numbers in Incubation_only_data
#run this for the full
rownames(Incubation_only_data) <- NULL

Incubation_only_data1<-na.omit(Incubation_only_data[4437: nrow(Incubation_only_data), ]) # 21:21008, 

Chamber_data_full1<-Chamber_data_full[720:12166, ]  # removes the first 2 runs when the sensor is warming up

Chamber_data_full1$CH4_4<-(Chamber_data_full1$CH4_3)/1000

divison_factor_reducing_lgr_density<-nrow(Incubation_only_data1)/nrow(Chamber_data_full1)

Incubation_only_data2 <- Incubation_only_data1[seq(1, NROW(Incubation_only_data1), by = divison_factor_reducing_lgr_density), ]


#before 9am data for plot

Incubation_only_data <- subset(hour.1, Chamber_Lid=="Closed")



#reset the row numbers in Incubation_only_data
#run this for the full
rownames(Incubation_only_data) <- NULL

#Incubation_only_data1<-na.omit(Incubation_only_data[4437:51499, ]) # 21:21008, 
Incubation_only_data1<-na.omit(Incubation_only_data[4437:45408, ]) # 21:21008, 

#Chamber_data_full1<-Chamber_data_full[720:8270, ]  # removes the first 2 runs when the sensor is warming up
Chamber_data_full1<-Chamber_data_full[720:7293, ]  # removes the first 2 runs when the sensor is warming up


Chamber_data_full1$CH4_4<-(Chamber_data_full1$CH4_3)/1000

divison_factor_reducing_lgr_density<-nrow(Incubation_only_data1)/nrow(Chamber_data_full1)

Incubation_only_data2 <- Incubation_only_data1[seq(1, NROW(Incubation_only_data1), by = divison_factor_reducing_lgr_density), ]



first_look_co21<- ggplot(data=Chamber_data_full1, aes(x=datetime, y=CO2))+
  geom_point()+
  # geom_point(aes(color = V35))+
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "15 mins")+
  
  xlab("Time (Minutes)") +
  ylab(expression ("CO"[2]*" Concentration (ppm)"))+
  theme(text = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        plot.title = element_text(size=10))

first_look_co21

first_look_co22<- ggplot(data=Incubation_only_data2, aes(x=datetime, y=CO2))+
  geom_point()+
  # geom_point(aes(color = V35))+
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "15 mins")+
  xlab("Time (Date-Time)") +
  ylab(expression ("CO"[2]*" Concentration (ppm)"))+
  theme(text = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        plot.title = element_text(size=10))

first_look_co22

final_plot_CO2<-plot_grid(first_look_co21, first_look_co22, ncol = 1, rel_heights = c(1, 1))
final_plot_CO2


first_look_CH41<- ggplot(data=Chamber_data_full1, aes(x=Time2, y=CH4_3))+
  #scale_y_continuous(trans='log2')+
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "15 mins")+
  geom_point()+
  #geom_point(aes(color = V35))+
  xlab("Time (Date-Time)") +
  ylab(expression ("CH"[4]*" Concentration (Differential mv)"))+
  #ylab(expression("Log"[2]*" [CH"[4]*" Concentration (ppm)]"))+
  theme(text = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        plot.title = element_text(size=10))

first_look_CH41

first_look_CH42<- ggplot(data=Incubation_only_data2, aes(x=datetime, y=CH4))+
  scale_y_continuous(trans='log2')+
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "15 mins")+
  geom_point()+
  #geom_point(aes(color = V35))+
  xlab("Time (Date-Time)") +
  # ylab(expression ("CH"[4]*" Concentration (ppm)"))+
  ylab(expression("Log"[2]*" [CH"[4]*" Concentration (ppm)]"))+
  theme(text = element_text(size=10),
        axis.text.x = element_text(size=10),
        axis.text.y = element_text(size=10),
        plot.title = element_text(size=10))

first_look_CH42

final_plot_CH4<-plot_grid(first_look_CH41, first_look_CH42, ncol = 1, rel_heights = c(1, 1))
final_plot_CH4

Chamber_data_full$Time1<-as.numeric(Chamber_data_full$datetime-1796) #edited time having aligned the data sets precicely
Chamber_data_full$Time2<-as.POSIXct(Chamber_data_full$datetime) #edited time having aligned the data sets precicely


#assess the data set in chunks #####
n <- nrow(Incubation_only_data2)
split_size <- ceiling(n / 4)

# Split the dataset into 4 subsets by row index
subsets <- split(Incubation_only_data2, ceiling(seq_len(n) / split_size))

# Create a ggplot for each subset; here we plot mpg versus wt
plot_list_lgr <- lapply(seq_along(subsets), function(i) {
  subset_df <- subsets[[i]]
  ggplot(data=subset_df, aes(x=datetime, y=CH4))+
    scale_y_continuous(trans='log2')+
    scale_x_datetime(date_labels = "%H:%M", date_breaks = "15 mins")+
    geom_point()+
    #geom_point(aes(color = V35))+
    xlab("Time (Date-Time)") +
    # ylab(expression ("CH"[4]*" Concentration (ppm)"))+
    ylab(expression("Log"[2]*" [CH"[4]*" Concentration (ppm)]"))+
    theme(text = element_text(size=10),
          axis.text.x = element_text(size=10),
          axis.text.y = element_text(size=10),
          plot.title = element_text(size=10))
})
  


plot_list_lgr[2]


#assess the data set in chunks #####
n <- nrow(Chamber_data_full1)
split_size <- ceiling(n / 4)

# Split the dataset into 4 subsets by row index
subsets <- split(Chamber_data_full1, ceiling(seq_len(n) / split_size))

# Create a ggplot for each subset; here we plot mpg versus wt
plot_list_chamber <- lapply(seq_along(subsets), function(i) {
  subset_df <- subsets[[i]]
  ggplot(data=subset_df, aes(x=Time2, y=CH4_3))+
    #scale_y_continuous(trans='log2')+
    scale_x_datetime(date_labels = "%H:%M", date_breaks = "15 mins")+
    geom_point()+
    #geom_point(aes(color = V35))+
    xlab("Time (Date-Time)") +
    ylab(expression ("CH"[4]*" Concentration (Differential mv)"))+
    #ylab(expression("Log"[2]*" [CH"[4]*" Concentration (ppm)]"))+
    theme(text = element_text(size=10),
          axis.text.x = element_text(size=10),
          axis.text.y = element_text(size=10),
          plot.title = element_text(size=10))
})

plot_list_chamber[1]



plot_list_together <- lapply(1:4, function(i) {
  plot_grid(plot_list_chamber[[i]], plot_list_lgr[[i]], ncol = 1, rel_heights = c(1, 1))
})

plot_list_together[2]




data <- data.frame(
  datetime = Incubation_only_data2$datetime,
  H1= Incubation_only_data2$H2O,
  T = Chamber_data_full1$Tmp,
  H = Chamber_data_full1$H2O,   # Select column F from df2
  Vout = Chamber_data_full1$CH4_3,  # Select column D from df2
  Observed = Incubation_only_data2$CH4  # Select column C from df1
)

data$Vout<-data$Vout/1000


#calibration with measures to prevent negative estimates

# model equation
model_eq <- Observed ~ C1 + C2 * exp(C3 * Vout - C4 * log(T + 273.15) - C5 * log(H + 1e-6)) - 
  C6 * log(H + 1e-6) * log(Vout + 1e-6) - 
  C7 * log((T + 273.15) * Vout + 1e-6) - 
  C8 * log(T + 273.15) * log(H + 1e-6)

# Set reasonable initial guesses
#initial_guess <- list(C1 = 1, C2 = 1, C3 = 0.1, C4 = 0.1, C5 = 0.1, C6 = 0.1, C7 = 0.1, C8 = 0.1)
initial_guess <- list(C1 = 0, C2 = 0, C3 = 0, C4 = 0, C5 = 0, C6 = 0, C7 = 0, C8 = 0) ## Initial estimates for all coefficients set to 0

# Fit the model using nlsLM
fit <- nlsLM(
  model_eq,
  data = data,
  start = initial_guess,
  control = nls.lm.control(ftol = 1e-8, maxiter = 200) # maxiter = 200
)

# View results
summary(fit)

# Extract fitted coefficients
fitted_constants <- coef(fit)
print(fitted_constants)

# Predict using the fitted model
data$Predicted <- predict(fit, newdata = data)

# **Force predictions to be non-negative**
data$Predicted <- pmax(0, data$Predicted)  # Set negative values to zero

# Compare predicted and observed values
print(data)



# Scatter plot of Observed vs Predicted
ggplot(data, aes(x = Observed, y = Predicted)) +
  geom_point(colour = "blue", size = 2) +  # Observed vs Predicted points
  geom_abline(intercept = 0, slope = 1, linetype = "dashed", colour = "red") +  # 1:1 line
  labs(
    title = "Observed vs Predicted Values",
    x = "Observed Values",
    y = "Predicted Values"
  ) +
  theme_minimal()

# Plot Residuals
data$Residuals <- data$Observed - data$Predicted

ggplot(data, aes(x = Predicted, y = Residuals)) +
  geom_point(colour = "darkgreen", size = 2) +
  geom_hline(yintercept = 0, linetype = "dashed", colour = "red") +
  labs(
    title = "Residuals vs Predicted Values",
    x = "Predicted Values",
    y = "Residuals"
  ) +
  theme_minimal()


# Calculate R²
rss <- sum((data$Observed - data$Predicted)^2)  # Residual sum of squares
tss <- sum((data$Observed - mean(data$Observed))^2)  # Total sum of squares
R2 <- 1 - (rss / tss)
cat("R² =", R2, "\n")

# Calculate NSE
NSE <- 1 - (rss / tss)
cat("NSE =", NSE, "\n")




#view predicted vs observed data together


data_long <- data %>%
  pivot_longer(cols = c("Observed", "Predicted"), names_to = "Type", values_to = "Value")

# Plot both columns
first_look_CH4 <- ggplot(data=data_long, aes(x=datetime, y=Value, colour=Type)) +
  #scale_y_continuous(trans='log2') +
  scale_x_datetime(date_breaks = "5 hours") +
  geom_point() +
  xlab("Time (Minutes)") +
  ylab(expression("Log"[2]*" [CH"[4]*" Concentration (ppm)]")) +
  theme(
    text = element_text(size=10),
    axis.text.x = element_text(size=10),
    axis.text.y = element_text(size=10),
    plot.title = element_text(size=10)
  )

first_look_CH4







#Methods paper plot figure 6#####
#using morning data

# Scatter plot of Observed vs Predicted
Observed_Vs_Predicted_plot<-ggplot(data, aes(x = Observed, y = Predicted)) +
  geom_point(size = 1.5, color = "black", fill = "white", shape = 21, stroke = 1) +  # Observed vs Predicted points
  geom_abline(intercept = 0, slope = 1, linetype = "dashed", colour = "red") +  # 1:1 line
  xlab(expression(bold("Observed CH"[4]*" Concentration (ppm)")))+
  ylab(expression(bold("Predicted CH"[4]*" Concentration (ppm)")))+
  scale_y_continuous(
    breaks = seq(min(0), 100, length.out = 5),  # Set the upper limit to 80
    limits = c(min(0), 100),                    # Force the y-axis to extend up to 80
    labels = scales::label_number(accuracy = 1)
  ) +
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12) ,
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10),  # Bold x-axis label
    axis.title.y = element_text(size = 10),
    legend.position = "none")

Observed_Vs_Predicted_plot


# Plot Residuals

residual_plot<-ggplot(data, aes(x = Predicted, y = Residuals)) +
  geom_point(size = 1.5, color = "black", fill = "white", shape = 21, stroke = 1) +  # Observed vs Predicted points
  geom_hline(yintercept = 0, linetype = "dashed", colour = "red") +
  xlab(expression(bold("Predicted CH"[4]*" Concentration (ppm)")))+
  ylab(expression(bold("Residuals")))+
  scale_x_continuous( breaks = seq(min(0), max(100), length.out = 5), limits = c(min(0), 100),    labels = scales::label_number(accuracy = 1))+
  scale_y_continuous(
    breaks = seq(min(-80), 80, length.out = 5),  # Set the upper limit to 80
    limits = c(min(-80), 80),                    # Force the y-axis to extend up to 80
    labels = scales::label_number(accuracy = 1)
  ) +
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12) ,
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10),  # Bold x-axis label
    axis.title.y = element_text(size = 10),
    #   axis.title.y = element_text(size = 10, margin = margin(r = 10)),
    legend.position = "none")

residual_plot



Predicted_observed_data_plot_inc_key <- ggplot(data = data_long[5859:12173, ], 
                                               aes(x = datetime, y = Value, color = Type)) +  # Use color for the border
  geom_point(size = 1.5, fill = "white", shape = 21, stroke = 1) +  # White fill, colored border
  xlab("Time (24 hour clock)") +
  ylab(expression(bold("CH"[4]*" Concentration (ppm)"))) +
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "90 mins") +
  scale_color_manual(name = "          Sensor Data:", 
                     labels = c("LGR Observed", "Figaro Modeled"), 
                     values = c("Observed" = full_pallett[1], 
                                "Predicted" = full_pallett[7])) +
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12, face = "bold"),
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(face = "bold", size = 10),  
    axis.title.y = element_text(size = 10),
    legend.position = "right"
  )

Predicted_observed_data_plot<- Predicted_observed_data_plot_inc_key + theme(legend.position = "none")
Predicted_observed_data_plot_legend <- get_legend(Predicted_observed_data_plot_inc_key) #use plot(figure_d_legend) to view


#plot the humidity data with time for illustration.

scale_factor<-4.94

humidity_plot_inc_key <- ggplot(data = data_long[5859:12173, ], aes(x = datetime)) +
  # Humidity points with white fill and colored border
  geom_point(aes(y = H, color = "Humidity"), fill = "white", shape = 21, stroke = 1.2, size = 1.5) +
  # Temperature points with white fill and colored border
  geom_point(aes(y = T * scale_factor, color = "Temperature"), fill = "white", shape = 21, stroke = 1.2, size = 1.5) +
  
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "90 mins") +
  scale_y_continuous(
    name = expression(bold("Relative Humidity (%)")),
    breaks = seq(min(80), max(100), length.out = 5),
    limits = c(min(80), 100),
    labels = scales::label_number(accuracy = 1), 
    sec.axis = sec_axis(
      trans = ~ . / scale_factor,  # Transform based on scale_factor
      name = "Temperature (°C)",
      breaks = seq(16, 22, length.out = 7),  # Define breaks manually
      labels = scales::label_number(accuracy = 1))
  )+
  scale_color_manual(name = "Chamber Conditions:", values = c("Humidity" = full_pallett[3], "Temperature" = full_pallett[8])) +  # Define colors
  xlab("Time (24 hour clock)") +
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12, face = "bold"),
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.text.y.right = element_text(size = 10), 
    axis.title.x = element_text(face = "bold", size = 10),  
    axis.title.y = element_text(face = "bold", size = 10),
    axis.title.y.right = element_text(face = "bold", size = 10),
    legend.position = "right"
  )
humidity_plot_inc_key

humidity_plot<- humidity_plot_inc_key + theme(legend.position = "none")
humidity_plot_legend <- get_legend(humidity_plot_inc_key) #use plot(figure_d_legend) to view

blank_plot <- ggplot() + 
  theme_void() + 
  theme(panel.background = element_rect(fill = "white", color = NA))


# Create top row witmargin()# Create top row with two side-by-side plots
top_row <- plot_grid(Observed_Vs_Predicted_plot, residual_plot, blank_plot, ncol = 3, rel_widths = c(1, 1, 0.14))
bottom_row <- plot_grid(Predicted_observed_data_plot, blank_plot, ncol = 2, rel_widths = c(1, 0.07))

# Combine all plots into final layout
final_plot <- plot_grid(
  top_row, 
  humidity_plot, 
  bottom_row, 
  ncol = 1, 
  rel_heights = c(1, 1, 1)  # Adjust height ratios if needed
)

final_plot





#save plot

ggsave("Figure_6.png", width = 160, height = 220, units = "mm") #saving the graph to the file directory


final_plot


#dev.off()
(while (!is.null(dev.list()))  dev.off())   



#save figure d legend
ggsave("Figure_6_legend1.png", plot = humidity_plot_legend, width = 50, height = 50, units = "mm")

#dev.off()
(while (!is.null(dev.list()))  dev.off()) 


#save figure d legend
ggsave("Figure_6_legend2.png", plot = Predicted_observed_data_plot_legend, width = 50, height = 50, units = "mm")

#dev.off()
(while (!is.null(dev.list()))  dev.off()) 




#figure 5 co2 ######


#Hollow point plot

co2_data <- data.frame(
  datetime = Incubation_only_data2$datetime,
  H1= Incubation_only_data2$H2O,
  T = Chamber_data_full1$Tmp,
  H = Chamber_data_full1$H2O,   # Select column F from df2
  Sensor = Chamber_data_full1$CO2,  # Select column D from df2
  Lgr = Incubation_only_data2$CO2,  # Select column C from df1
  residuals = ((Incubation_only_data2$CO2) - (Chamber_data_full1$CO2))
)

#offset the co2 sensor to calibrate it to the lgr

sensor_calibration_offset<-
  
  co2_data$Sensor<-co2_data$Sensor-(mean(co2_data$Sensor)-mean(co2_data$Lgr))

df1<- data.frame(datetime = Incubation_only_data2$datetime, Value = co2_data$Sensor, Type= "Sensor")

df2<- data.frame(datetime = Incubation_only_data2$datetime, Value = co2_data$Lgr, Type= "LGR")


# Fit regression model: reference as response, new sensor as predictor
model <- lm(co2_data$Sensor ~ co2_data$Lgr)

# Extract residuals and fitted values
residuals <- resid(model)
fitted_values <- fitted(model)

# Plot residuals
plot(fitted_values, residuals,
     xlab = "Fitted Values (Predicted Reference)",
     ylab = "Residuals",
     main = "Residual Plot")
abline(h = 0, col = "red", lty = 2)

# Calculate R²
summary_model <- summary(model)
r_squared <- summary_model$r.squared
cat("R-squared:", r_squared, "\n")

# Calculate discrepancy (difference)
discrepancy <- co2_data$Sensor - co2_data$Lgr

# Average discrepancy (mean)
mean_discrepancy <- mean(discrepancy)

# Standard deviation of discrepancy
sd_discrepancy <- sd(discrepancy)

# Range of discrepancy
range_discrepancy <- range(discrepancy)
range_span <- diff(range_discrepancy)

# Print results
cat("Mean discrepancy:", mean_discrepancy, "\n")
cat("Standard deviation:", sd_discrepancy, "\n")
cat("Discrepancy range:", range_discrepancy[1], "to", range_discrepancy[2], "\n")
cat("Range span:", range_span, "\n")


# Combine the dataframes and arrange by datetime
combined_df_co2 <- bind_rows(df1, df2) %>%
  arrange(datetime)

co2_data$residuals<-((co2_data$Lgr) - (co2_data$Sensor))

# Scatter plot of Observed vs Predicted
Observed_Vs_Predicted_plot<-ggplot(co2_data, aes(x = Lgr, y = Sensor)) +
  geom_point(size = 1.5, color = "black", fill = "white", shape = 21, stroke = 1) +  # Observed vs Predicted points
  geom_abline(intercept = 0, slope = 1, linetype = "dashed", colour = "red") +  # 1:1 line
  xlab(expression(bold("Los Gatos CO"[2]*" Concentration (ppm)")))+
  ylab(expression(bold("SCD30 CO"[2]*" Concentration (ppm)")))+
  scale_x_continuous(
    breaks = seq(min(375), 575, length.out = 5),  # Set the upper limit to 80
    limits = c(min(375), 575),                    # Force the y-axis to extend up to 80
    labels = scales::label_number(accuracy = 1)
  ) +
  scale_y_continuous(
    breaks = seq(min(375), 575, length.out = 5),  # Set the upper limit to 80
    limits = c(min(375), 575),                    # Force the y-axis to extend up to 80
    labels = scales::label_number(accuracy = 1)
  ) +
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12) ,
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10),  # Bold x-axis label
    axis.title.y = element_text(size = 10),
    legend.position = "none")

Observed_Vs_Predicted_plot


# Plot Residuals

resid_data <- data.frame(
  Fitted = fitted_values,
  Residuals = residuals
)

residual_plot<-ggplot(resid_data, aes(x = fitted_values, y = residuals)) +
  geom_point(size = 1.5, color = "black", fill = "white", shape = 21, stroke = 1) +  # Observed vs Predicted points
  geom_hline(yintercept = 0, linetype = "dashed", colour = "red") +
  xlab(expression(bold("SCD30 CO"[2]*" Concentration (ppm)")))+
  ylab(expression(bold("Residuals")))+
  scale_x_continuous( breaks = seq(min(350), max(550), length.out = 5), limits = c(min(350), 550),    labels = scales::label_number(accuracy = 1))+
  scale_y_continuous(
    breaks = seq(min(-100), 100, length.out = 5),  # Set the upper limit to 80
    limits = c(min(-100), 100),                    # Force the y-axis to extend up to 80
    labels = scales::label_number(accuracy = 1)
  ) +
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12) ,
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.title.x = element_text(size = 10),  # Bold x-axis label
    axis.title.y = element_text(size = 10),
    legend.position = "none")

residual_plot

#plot predicted and observed data together
Predicted_observed_data_plot_inc_key<-ggplot(combined_df_co2, aes(x=datetime, y=Value, colour=Type)) +
  #scale_y_continuous(trans='log2') +
  geom_point(size = 1.5, fill = "white", shape = 21, stroke = 1) +  # White fill, colored border
  xlab("Time (24 hour clock)") +
  ylab(expression(bold("CO"[2]*" Concentration (ppm)"))) +
  scale_x_datetime(date_labels = "%H:%M", date_breaks = "3 hour")+ 
  scale_y_continuous(
    breaks = seq(min(350), 550, length.out = 5),  # Set the upper limit to 80
    limits = c(min(350), 550),                    # Force the y-axis to extend up to 80
    labels = scales::label_number(accuracy = 1)
  ) +
  scale_color_manual(name = "          Measurement Device:", labels = c("Los Gatos Ultraportable", "Sensirion SCD30"), values=c("LGR" = full_pallett[1], "Sensor" = full_pallett[7]))+
  theme(
    panel.background = element_rect(fill = "white", colour = "white"),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.background = element_rect(fill = "white"),
    legend.title = element_text(size = 12, face = "bold"),
    legend.key.size = unit(2, "lines"),
    legend.text = element_text(size = 12),
    plot.title = element_text(size = 10, face = "bold"),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10),
    axis.text.y.right = element_text(size = 10), 
    axis.title.x = element_text(face = "bold", size = 10),  
    axis.title.y = element_text(face = "bold", size = 10),
    axis.title.y.right = element_text(face = "bold", size = 10),
    legend.position = "right"
  )

Predicted_observed_data_plot<- Predicted_observed_data_plot_inc_key + theme(legend.position = "none")
Predicted_observed_data_plot_legend_CO2 <- get_legend(Predicted_observed_data_plot_inc_key) #use plot(figure_d_legend) to view




top_row <- plot_grid(Observed_Vs_Predicted_plot, residual_plot, ncol = 2)  # Top row: p1 and p2 side by side
final_plot <- plot_grid(top_row, Predicted_observed_data_plot, ncol = 1, rel_heights = c(1, 1))  # Combine rows

# Display the plot
final_plot


#save plot

ggsave("Figure_5.png", width = 150, height = 150, units = "mm") #saving the graph to the file directory


final_plot


#dev.off()
(while (!is.null(dev.list()))  dev.off())   



#save figure d legend
ggsave("Figure_5_legend.png", plot = Predicted_observed_data_plot_legend_CO2, width = 70, height = 50, units = "mm")

#dev.off()
(while (!is.null(dev.list()))  dev.off()) 

